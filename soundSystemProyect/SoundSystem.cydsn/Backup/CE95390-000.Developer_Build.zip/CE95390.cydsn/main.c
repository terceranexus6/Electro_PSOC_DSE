/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*   This project enumerates USBFS component as a 8-bits, 32kHz, mono USB Audio 
*   Device. The audio data is passed to 8-bit DAC using two DMAs. One DMA is 
*   integrated in USBFS component used for sending and receiving data to/ from 
*   the memory cyclic buffer; the other DMA (VDACoutDMA) moves data from memory 
*   buffer to VDAC8.
*   
*   The synchronization of incoming transfers with internal 32kHz clock is done
*   by the software. It works when cyclic buffer overflows.
*   When internal 32kHz clock is faster compared to PC transactions, VDACoutDMA 
*   stops for a while to fill the buffer.
*   When internal 32kHz clock is slower compared to PC transactions, then one
*   USB transfer is skipped.
*
* To test project:
*  1. Select 3.3V in SW3 and plug-in power to the CY8CKIT-001
*  2. Build USBFS_Audio project and program the hex file on to the target 
*     device
*  3. Connect USB cable from computer to CY8CKIT-001
*  4. Connect active Speaker to port P1[7] and Ground
*  5. Open Sound and Audio Devices Properties on PC, select CypressAudioControl 
*     device in Audio Tab 
*  6. Play the audio on PC
*  7. Listen the audio on the speaker or observe the signal on oscilloscope.
*
* Related Document:
*  Universal Serial Bus Specification Revision 2.0 
*  Universal Serial Bus Device Class Definition for Audio Devices Release 1.0
*
********************************************************************************
* Copyright 2012, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <device.h>

#define AUDIO_INTERFACE (1u)
#define OUT_EP          (2u)

#define NUM_BUF         (10u)
#define TRANS_SIZE      (32u)
#define BUFSIZE         (TRANS_SIZE*NUM_BUF)

uint8 soundBuffer[BUFSIZE];
volatile uint16 outIndex = 0u;
volatile uint16 inIndex = 0u;

volatile uint8 syncDMA = 0u;
volatile uint8 syncDMA_counter = 0u; 

/* Variable declarations for VDACoutDMA */
uint8 VDACoutDMA_Chan;
uint8 VDACoutDMA_TD[NUM_BUF];
  
extern uint8 USBFS_DmaChan[];
extern uint8 USBFS_DmaTd[];


/*******************************************************************************
* Function Name: DMA_done
********************************************************************************
*
* Summary:
*   Local Interrupt Service Routine for increment out buffer pointer and 
*   synchronization. 
*******************************************************************************/
CY_ISR(DMA_done)
{
    if(++outIndex >= NUM_BUF)
    {
        outIndex = 0u;
    }
    /* When the internal 32kHz clock is faster compare to PC trasactions */
    if(outIndex == inIndex)
    {
        /* Stop DMA*/
        CyDmaChDisable(VDACoutDMA_Chan);
        /* resync DMA, wait on half buffer data and re-enable DAC DMA */
        syncDMA = 0u;
        syncDMA_counter = 0u;
    }
}

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  Initialize the componets and do the software synchronization.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void main()
{
    uint8 i;
    uint8 skip_next_OUT = 0;
    
    VDAC8_Start();
    VDACoutDMA_done_isr_StartEx(DMA_done);

    LCD_Start();
    LCD_PrintString("USB->DMA->DAC");

   /* DMA Configuration for VDACoutDMA (Memory to VDAC) */
    #define VDACoutDMA_BYTES_PER_BURST      1
    #define VDACoutDMA_REQUEST_PER_BURST    1
    #define VDACoutDMA_DST_BASE             (CYDEV_PERIPH_BASE)
    #if (defined(__C51__))          /* PSoC 3 - Source is SRAM */
        #define VDACoutDMA_SRC_BASE         (CYDEV_SRAM_BASE)
    #else                           /* PSoC 5 */
        #define VDACoutDMA_SRC_BASE         (soundBuffer)
    #endif  /* End C51 */  
    VDACoutDMA_Chan = VDACoutDMA_DmaInitialize(VDACoutDMA_BYTES_PER_BURST, VDACoutDMA_REQUEST_PER_BURST, 
                                     HI16(VDACoutDMA_SRC_BASE), HI16(VDACoutDMA_DST_BASE));
    for (i = 0u; i < NUM_BUF; i++) 
    {
        VDACoutDMA_TD[i] = CyDmaTdAllocate();
    }    
    for (i = 0u; i < (NUM_BUF-1); i++) 
    {
        CyDmaTdSetConfiguration(VDACoutDMA_TD[i], TRANS_SIZE, VDACoutDMA_TD[i+1], TD_INC_SRC_ADR | 
                                                                                  VDACoutDMA__TD_TERMOUT_EN);
    }
    CyDmaTdSetConfiguration(VDACoutDMA_TD[NUM_BUF-1], TRANS_SIZE, VDACoutDMA_TD[0], TD_INC_SRC_ADR | 
                                                                                  VDACoutDMA__TD_TERMOUT_EN);
    for (i = 0u; i < NUM_BUF; i++) 
    {
        CyDmaTdSetAddress(VDACoutDMA_TD[i], LO16((uint32)&soundBuffer[TRANS_SIZE*i]), LO16((uint32)VDAC8_Data_PTR));
    }    
    CyDmaChSetInitialTd(VDACoutDMA_Chan, VDACoutDMA_TD[0]);

    CyGlobalIntEnable;  /* enable global interrupts. */

    /* Start USBFS Operation with 3V operation */
    USBFS_Start(0, USBFS_3V_OPERATION);   
    /* Wait for Device to enumerate */
    while(!USBFS_GetConfiguration());    


    for(;;)
    {

        if(USBFS_IsConfigurationChanged() != 0u) 
        {
            /* Check the active Alternative setting when configuration changed */
            if((USBFS_GetConfiguration() != 0u) && (USBFS_GetInterfaceSetting(AUDIO_INTERFACE) != 0u))
            {   /* Enable OUT EP and init local variables when Alternate 1 with AudioStreaming interface has been set */
                inIndex = 0u;
                outIndex = 0u;
                syncDMA = 0u;
                syncDMA_counter = 0u;
                skip_next_OUT = 0u;
                USBFS_EnableOutEP(OUT_EP);
                LCD_Position(1,0);
                LCD_PrintString("Audio ON ");
            }    
            else    /* Zero Alternate setting for mute */
            {
                LCD_Position(1,0);
                LCD_PrintString("Audio OFF");
            }
        }
        if (USBFS_GetEPState(OUT_EP) == USBFS_OUT_BUFFER_FULL)
        {
            if(skip_next_OUT == 0u)
            {
                /* Read OUT_EP using DMA */
                USBFS_ReadOutEP(OUT_EP, &soundBuffer[inIndex*TRANS_SIZE], TRANS_SIZE); 
                if(++inIndex >= NUM_BUF)
                {
                    inIndex = 0u;
                }
                syncDMA_counter++;
            }
            else 
            {
                /* Skip this transfer, Re-arm OUT endpoint */
                USBFS_EnableOutEP(OUT_EP);
                skip_next_OUT = 0u;
            }
            /* When the internal 32kHz clock is slower compare to PC trafic */
            if(outIndex == inIndex)
            {
                /* Then skip next transfer from PC */
                skip_next_OUT = 1u;
            }
        }
        if((syncDMA == 0) && (syncDMA_counter >= (NUM_BUF/2)))
        {
            CyDmaChEnable(VDACoutDMA_Chan, 1);
            syncDMA = 1u;
        }    
    }
}


/* [] END OF FILE */
